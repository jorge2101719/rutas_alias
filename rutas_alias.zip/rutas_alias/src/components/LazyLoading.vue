<template>
    <div>
        <h1>Este componente se está cargando con retraso</h1>
        <img src="https://vuejs.org/images/transition.png" alt="">
    </div>
</template>