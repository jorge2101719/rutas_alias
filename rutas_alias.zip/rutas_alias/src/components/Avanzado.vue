<template>
    <div class="admin">
        <router-link :to="administrador">Simple</router-link>
        <h1><strong>Esta página de administración está en construcción. Intente como administrador simple</strong></h1>
    </div>
</template>

<script>
export default {
    
}
</script>

<style>

</style>



