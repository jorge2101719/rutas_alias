<template>
    <div class="admin">
        <header class="masthead" style="background-image:url('assets/img/home-bg.jpg');">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-10 col-lg-8 mx-auto">
                        <div class="site-heading">
                            <h1>V8</h1><span class="subheading"> Página del administrador </span></div>
                    </div>
                </div>
            </div>
        </header>
        <!--<router-link to="simple"></router-link>-->
    </div>
</template>

<script>
export default {
//    data(){
//        return {
//            mensaje: `Página del administrador`,
//        }
//    }    
}
</script>

<style>

</style>