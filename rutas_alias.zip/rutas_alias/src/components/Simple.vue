<template>
    <div>
        <h1><strong>Bienvenido a la página de Administración</strong></h1>
    </div>
</template>

<script>
export default {
    //props: ['simple'],
    //computed: {
    //    titulo(){return `Bienvenido a la página de Administración ${this.simple}`}
    //}
}
</script>

<style>

</style>
