<template>
  <div>
    <nav class="navbar navbar-light navbar-expand-lg fixed-top" id="mainNav">
        <div class="container"><a class="navbar-brand">V8</a><button data-toggle="collapse" data-target="#navbarResponsive" class="navbar-toggler" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><i class="fa fa-bars"></i></button>
            <div
                class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="nav navbar-nav ml-auto">
                    <li class="nav-item" role="presentation"><router-link :to="{name: 'inicio'}">portada</router-link></li>
                    <li class="nav-item" role="presentation"><router-link :to="{name: 'sobremi'}">sobre mí</router-link></li>
                    <li class="nav-item" role="presentation"><router-link :to="{name: 'contacto'}">contacto</router-link></li>
                    <li class="nav-item" role="presentation"><router-link to="/post/1">último post</router-link></li>
                    <!--<li class="nav-item" role=""><router-link :to="{name: 'administrador'}">Administrador</router-link></li>-->
                </ul>
        </div>
        </div>
    </nav>
    <transition name="metamorfo">
      <router-view></router-view>
    </transition>
  </div>
  
</template>

<script>

export default {
  name: 'App',
//  data() {
//    return{
//      mostrar: true
//    }
//  },
//  methods: {
//    mostrar() {
//      this.mostrar = !this.mostrar
//    }
//  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
.metamorfo-enter-active, .metamorfo-leave-active {
  transition: opacity .1s, padding .1s;
}
.metamorfo-enter, .metamorfo-leave-to {
  opacity: 0;
  padding: 10px;
}
.metamorfo-enter-to, .metamorfo-leave{
  opacity: 1;
  padding: 0px;
}
</style>
