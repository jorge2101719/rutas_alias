import Vue from 'vue'
import Router from 'vue-router'

import Inicio from './components/Inicio'
import SobreMi from './components/SobreMi'
import Contacto from './components/Contacto'
import Post from './components/Post'
import Articulo from './components/Articulo'
//import Administrador from './components/Administrador'
//import Simple from './components/Simple'
//import Avanzado from './components/Avanzado'
//import Portada from './components/Portada'
//import { hasOwnMetadata } from 'core-js/fn/reflect'
import NotFound from './components/NotFound'

const LazyLoading = () => import('./components/LazyLoading')

Vue.use(Router)

export default new Router({
    mode: 'history', 
    routes: [
        {
            path: '/',
            name: 'inicio',
            component: Inicio,
            alias: ['/inicio', '/home', '/portada'],
            children: [
                {
                    path: '',
                    component: {
                        lazyloading: LazyLoading
                    }
                }
            ]
        },
        {
            path: '/sobremi',
            name: 'sobremi',
            component: SobreMi,
            alias: ['/acerca'],
            children: [
                {
                    path: '',
                    component: {
                        lazyloading: LazyLoading
                    }
                }
            ]
        },
        {
            path: '/contacto',
            name: 'contacto',
            component: Contacto,
            alias: ['/contactame'],
            children: [
                {
                    path: '',
                    component: {
                        lazyloading: LazyLoading
                    }
                }
            ]
        },
        {
            path: '/post',
            name: 'post',
            component: Post,
            children: [
                {
                    path: ':articulo',
                    component: Articulo,
                },
                {
                    path: '',
                    component: {
                        lazyloading: LazyLoading
                    }
                }
            ]
        },
        {
            path: '/administrador/',
            name: 'administrador',
            alias: ['/admin', '/admi'],
            component: () => import('./components/Administrador'),
            children: [
                {
                    path: 'simple',
                    name: 'simple',
                    //component: Simple,
                    component: () => import('./components/Simple.vue'),
                    //redirect: '/administrador'
                },
                {
                    path: 'avanzado',
                    name: 'avanzado',
                    //component: Avanzado,
                    component: () => import('./components/Avanzado.vue'),
                }
            ]
        },
        {
            path: '*',
            component: NotFound
        }
    ]
})