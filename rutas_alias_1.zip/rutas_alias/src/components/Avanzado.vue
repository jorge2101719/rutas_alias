<template>
    <div>
        <h1><strong>{{aviso}}</strong></h1>
    </div>
</template>

<script>
export default {
    name: 'avanzado',
    data(){
        return {
            aviso: `Esta página de administración está en construcción. Intente como administrador simple`
        }
    }
}
</script>

<style>

</style>



