<template>
    <div>
        <h1><strong>{{aviso}}</strong></h1>
    </div>
</template>

<script>
export default {
    name: 'simple',
    data() {
        return {
            aviso: 'Bienvenido a la página de Administación'
        }
    }
//    computed: {
//        titulo(){return `Bienvenido a la página de Administración ${this.simple}`}
//    }
}
</script>

<style>

</style>
