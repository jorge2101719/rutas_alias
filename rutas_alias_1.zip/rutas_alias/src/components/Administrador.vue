<template>
    <div class="admin">
        <header class="masthead" style="background-image:url('assets/img/home-bg.jpg');">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-10 col-lg-8 mx-auto">
                        <div class="site-heading">
                            <h1>V8</h1><span class="subheading"> {{aviso}} </span>
                            <router-link :to="{name: 'simple'}"></router-link>
                            <router-view></router-view>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!--<router-link to="simple"></router-link>-->
    </div>
</template>

<script>
//import Simple from '@/components/Simple'
//import Avanzado from '@/components/Avanzado'

export default {
    name: 'administrador',
//    components : {
//        Simple,
//        Avanzado
//    },
    data(){
        return {
            aviso: 'Página del administrador',
        }
    },
//    methods: {
//        ruta(){
//            if(ruta) {
//                <Simple></Simple>
//            } else {
//                <Avanzado></Avanzado>
//            }
//        }
//    }
}
</script>

<style>

</style>